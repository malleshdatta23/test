# Teradata Lineage Extractor (Python 3.11)

This project parses Teradata view definitions and builds a **lineage tree**
from a root VIEW down to all underlying TABLES (and intermediate VIEWS).

It is designed so you can:
- Start locally with **mock view definitions** (no DB connection needed)
- Later **swap in a real Teradata connection** by editing `teradata_client.py`

---

## Quick Start (Mock Mode)

```bash
cd teradata_lineage

# Run lineage for mock view v1
python main.py --root v1 --root-type VIEW --mock examples/mock_views.json
```

Expected tree:

```text
v1 (VIEW)
└── v2 (VIEW)
    ├── v3 (VIEW)
    │   └── t2 (TABLE)
    └── t1 (TABLE)
```

And JSON will be printed to stdout.

---

## Files

- `main.py` — CLI entry point
- `lineage/parser.py` — very simple SQL parser to extract table/view references
- `lineage/lineage_builder.py` — recursive lineage builder + Node class
- `lineage/teradata_client.py` — abstraction for Teradata access (mock + hook for real DB)
- `examples/mock_views.json` — sample `SHOW VIEW` outputs
- `examples/run_mock_example.sh` — sample run command

You can upload this folder as a project or zip it and feed to your tools.