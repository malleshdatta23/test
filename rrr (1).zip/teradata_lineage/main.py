import argparse
import json
from pathlib import Path

from lineage.lineage_builder import build_lineage
from lineage.teradata_client import MockTeradataViewProvider  # RealTeradataViewProvider is also available


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build a lineage tree for a Teradata VIEW (mock or real provider)."
    )
    parser.add_argument(
        "--root",
        required=True,
        help="Root object name (usually a VIEW)",
    )
    parser.add_argument(
        "--root-type",
        default="VIEW",
        choices=["VIEW", "TABLE"],
        help="Type of the root object (default: VIEW)",
    )
    parser.add_argument(
        "--mock",
        help="Path to JSON file with mock view definitions (enables mock provider)",
    )
    parser.add_argument(
        "--to-json",
        help="Optional path to write JSON lineage (if omitted, JSON is printed to stdout)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.mock:
        provider = MockTeradataViewProvider(args.mock)
    else:
        raise SystemExit(
            "This demo is configured for mock mode only. Provide --mock path to a JSON file.\n"
            "Later, you can swap to RealTeradataViewProvider in main.py."
        )

    node = build_lineage(
        root_name=args.root,
        root_type=args.root_type,
        provider=provider,
    )

    print("\n=== Lineage Tree ===")
    # Root printed without leading indent symbol for nicer look
    print(f"{node.name} ({node.type})")
    for i, child in enumerate(node.children):
        child.print_tree("", i == len(node.children) - 1)

    lineage_dict = node.to_dict()

    if args.to_json:
        out_path = Path(args.to_json)
        out_path.write_text(json.dumps(lineage_dict, indent=2), encoding="utf-8")
        print(f"\nJSON lineage written to: {out_path}")
    else:
        print("\n=== JSON Lineage ===")
        print(json.dumps(lineage_dict, indent=2))


if __name__ == "__main__":
    main()