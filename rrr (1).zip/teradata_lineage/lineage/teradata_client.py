from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Dict


class MockTeradataViewProvider:
    """Simple JSON-backed view provider for local testing.

    JSON structure example (mock_views.json):

    {
      "v1": "CREATE VIEW v1 AS SELECT * FROM v2;",
      "v2": "REPLACE VIEW v2 AS SELECT * FROM v3 JOIN t1;",
      "v3": "REPLACE VIEW v3 AS SELECT * FROM t2;"
    }

    All keys are treated as VIEWS.
    Any object referenced in SQL but not a key is treated as TABLE.
    """

    def __init__(self, json_path: str):
        path = Path(json_path)
        if not path.exists():
            raise FileNotFoundError(f"Mock views file not found: {json_path}")
        with path.open("r", encoding="utf-8") as f:
            self.views: Dict[str, str] = json.load(f)

    def get_view_definition(self, view_name: str) -> Optional[str]:
        return self.views.get(view_name)

    def get_object_type(self, object_name: str) -> str:
        if object_name in self.views:
            return "VIEW"
        return "TABLE"


class RealTeradataViewProvider:
    """Skeleton for a real Teradata-backed provider.

    NOTE:
    - This class is intentionally left as a template.
    - You need to fill in the connection details for your environment.
    - We do NOT import teradatasql here to avoid errors in restricted environments.
    """

    def __init__(self, dsn: str | None = None, user: str | None = None, password: str | None = None):
        self.dsn = dsn
        self.user = user
        self.password = password
        # TODO: initialize real connection here in your environment.

    def get_view_definition(self, view_name: str) -> Optional[str]:
        """Return the SQL text for SHOW VIEW <view_name>.

        In your real code, you might:
        - Connect using teradatasql
        - Run: SHOW VIEW <view_name>;
        - Capture the text and return it
        """
        raise NotImplementedError(
            "RealTeradataViewProvider.get_view_definition must be implemented in your environment."
        )

    def get_object_type(self, object_name: str) -> str:
        """Return 'VIEW' or 'TABLE' using DBC tables in Teradata.

        Example idea (for you to implement):
        - SELECT TableKind FROM DBC.TablesV WHERE TableName = ? AND DatabaseName = ?;
        - Map 'V' -> 'VIEW', 'T' -> 'TABLE'
        """
        raise NotImplementedError(
            "RealTeradataViewProvider.get_object_type must be implemented in your environment."
        )