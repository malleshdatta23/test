import re
from typing import Set, Iterable


def _strip_comments(sql: str) -> str:
    """Remove basic SQL comments (/* */ and --)."""
    # Remove /* ... */ comments
    sql = re.sub(r'/\*.*?\*/', ' ', sql, flags=re.DOTALL)
    # Remove -- comments
    sql = re.sub(r'--.*?$', ' ', sql, flags=re.MULTILINE)
    return sql


def _normalize_whitespace(sql: str) -> str:
    return re.sub(r'\s+', ' ', sql).strip()


def extract_objects(sql: str) -> Set[str]:
    """Very simple extractor for object names used in FROM / JOIN clauses.

    This is NOT a full SQL parser, but good enough for many Teradata view definitions:
    - Handles FROM <obj> and JOIN <obj>
    - Ignores aliases
    - Works across line breaks and with basic comments

    Returns a set of object names as strings (without quotes).
    """
    if not sql:
        return set()

    cleaned = _normalize_whitespace(_strip_comments(sql))

    # Regex to capture objects after FROM or JOIN
    pattern = re.compile(r"\b(?:FROM|JOIN)\s+([A-Za-z0-9_\"\.]+)", re.IGNORECASE)
    matches = pattern.findall(cleaned)

    objects = set()
    for m in matches:
        obj = m.strip()
        # Remove optional double quotes
        obj = obj.replace('"', '')
        if obj:
            objects.add(obj)

    return objects


def demo_extract(sqls: Iterable[str]) -> None:
    """Helper for quick testing in REPL."""
    for s in sqls:
        print("SQL:", s)
        print(" ->", extract_objects(s))
        print()