from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional, Protocol

from .parser import extract_objects


class ViewProvider(Protocol):
    """Protocol for objects that can return view definitions and types.

    This allows us to plug in either:
    - a mock provider (JSON file)
    - a real Teradata-backed provider
    """

    def get_view_definition(self, view_name: str) -> Optional[str]:
        ...

    def get_object_type(self, object_name: str) -> str:
        """Return 'VIEW' or 'TABLE' (or 'UNKNOWN' as fallback)."""
        ...


@dataclass
class LineageNode:
    name: str
    type: str  # "VIEW" or "TABLE" or "UNKNOWN"
    children: List["LineageNode"] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "type": self.type,
            "children": [c.to_dict() for c in self.children],
        }

    def print_tree(self, indent: str = "", is_last: bool = True) -> None:
        """Pretty-print this node as an ASCII tree."""
        connector = "└── " if is_last else "├── "
        print(f"{indent}{connector}{self.name} ({self.type})")
        if self.children:
            child_indent = indent + ("    " if is_last else "│   ")
            for i, child in enumerate(self.children):
                last = i == len(self.children) - 1
                child.print_tree(child_indent, last)


def build_lineage(
    root_name: str,
    root_type: str,
    provider: ViewProvider,
    visited: Optional[Set[str]] = None,
) -> LineageNode:
    """Recursively build a lineage tree starting from root_name.

    - root_type is typically 'VIEW' or 'TABLE'.
    - provider supplies view SQL and type info.
    - visited prevents infinite recursion on cycles.
    """
    if visited is None:
        visited = set()

    normalized_type = root_type.upper()
    node = LineageNode(name=root_name, type=normalized_type)

    if normalized_type == "TABLE":
        # Base case: stop recursion
        return node

    if root_name in visited:
        # Cycle protection: mark and stop
        cycle_node = LineageNode(
            name=f"[CYCLE DETECTED at {root_name}]", type="CYCLE", children=[]
        )
        node.children.append(cycle_node)
        return node

    visited.add(root_name)

    # Only views should have children in this simple model
    if normalized_type != "VIEW":
        return node

    view_sql = provider.get_view_definition(root_name)
    if not view_sql:
        # Cannot resolve definition
        return node

    child_objects = extract_objects(view_sql)

    for obj in sorted(child_objects):
        child_type = provider.get_object_type(obj)
        child_node = build_lineage(
            root_name=obj,
            root_type=child_type,
            provider=provider,
            visited=visited,
        )
        node.children.append(child_node)

    return node