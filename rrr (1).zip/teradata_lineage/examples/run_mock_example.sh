#!/usr/bin/env bash
# Simple example runner for the mock view lineage.

python main.py --root v1 --root-type VIEW --mock examples/mock_views.json