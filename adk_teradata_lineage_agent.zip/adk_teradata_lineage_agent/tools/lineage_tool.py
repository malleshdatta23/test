"""ADK tool that exposes the lineage engine to the agent.

This file is designed so that the same logic can be used:
- inside ADK (via the @tool decorator), or
- directly from Python (just call get_teradata_lineage()).
"""

from typing import Optional, Literal, Dict, Any

try:
    # ADK-style import; adjust if your runtime exposes a different decorator
    from adk import tool
except ImportError:
    # Fallback no-op decorator so this file still works in plain Python
    def tool(*args, **kwargs):
        def decorator(fn):
            return fn
        return decorator

from lineage_engine.lineage_builder import build_lineage
from lineage_engine.teradata_client import (
    MockTeradataViewProvider,
    RealTeradataViewProvider,
)


@tool()
def get_teradata_lineage(
    view_name: str,
    mode: Literal["mock", "teradata"] = "mock",
    database: Optional[str] = None,
    mock_file_path: str = "examples/mock_views.json",
) -> Dict[str, Any]:
    """Build lineage for a Teradata view.

    Parameters
    ----------
    view_name:
        Name of the root VIEW (can be database-qualified).
    mode:
        "mock"     → use MockTeradataViewProvider with a JSON file.
        "teradata" → use RealTeradataViewProvider and call a live DB.
    database:
        Optional default database. Useful when object names in SQL are not
        fully qualified.
    mock_file_path:
        Path to JSON file used in mock mode.

    Returns
    -------
    dict
        A JSON-serializable dict representing the lineage tree.
    """

    if mode == "mock":
        provider = MockTeradataViewProvider(mock_file_path)
        root_type = "VIEW"  # by definition for mock keys
    elif mode == "teradata":
        # In a real deployment, pull these from environment or secret manager.
        # For now they are placeholders you should edit for your environment.
        host = "YOUR_TD_HOST"
        user = "YOUR_TD_USER"
        password = "YOUR_TD_PASSWORD"

        provider = RealTeradataViewProvider(
            host=host,
            user=user,
            password=password,
            database=database,
        )
        root_type = "VIEW"
    else:
        raise ValueError(f"Unsupported mode: {mode}. Use 'mock' or 'teradata'.")

    node = build_lineage(
        root_name=view_name,
        root_type=root_type,
        provider=provider,
    )

    return node.to_dict()