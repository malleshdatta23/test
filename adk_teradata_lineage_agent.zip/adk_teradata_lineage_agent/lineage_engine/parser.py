import re
from typing import Set, Iterable


def _strip_comments(sql: str) -> str:
    """Remove basic SQL comments (/* */ and --)."""
    sql = re.sub(r'/\*.*?\*/', ' ', sql, flags=re.DOTALL)
    sql = re.sub(r'--.*?$', ' ', sql, flags=re.MULTILINE)
    return sql


def _normalize_whitespace(sql: str) -> str:
    return re.sub(r'\s+', ' ', sql).strip()


def extract_objects(sql: str) -> Set[str]:
    """Extract object names that appear after FROM / JOIN in the SQL.

    Supports:
    - Simple FROM table
    - JOIN table
    - Left/Right/Outer joins
    - Database-qualified names (db.table)
    - FROM inside subqueries

    This is still not a full SQL parser, but works for many Teradata views.
    """
    if not sql:
        return set()

    cleaned = _strip_comments(sql)

    # We intentionally do NOT squash all whitespace to keep structure for subqueries.
    pattern = re.compile(
        r"\b(?:FROM|JOIN)\s+([A-Za-z0-9_\.]+)",
        re.IGNORECASE,
    )

    matches = pattern.findall(cleaned)

    objects = set()
    for m in matches:
        obj = m.strip()
        # Ignore keywords that might slip through (very defensive)
        if obj.upper() in {"SELECT", "TABLE", "VIEW"}:
            continue
        objects.add(obj)

    return objects


def demo_extract(sqls: Iterable[str]) -> None:
    for s in sqls:
        print("SQL:", s)
        print(" ->", extract_objects(s))
        print()