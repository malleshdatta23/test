from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Dict


class MockTeradataViewProvider:
    """JSON-backed view provider for mock mode.

    JSON structure example:

    {
      "v1": "CREATE VIEW v1 AS SELECT * FROM v2;",
      "v2": "REPLACE VIEW v2 AS SELECT * FROM v3 JOIN t1;",
      "v3": "REPLACE VIEW v3 AS SELECT * FROM t2;"
    }

    Keys are treated as VIEWS.
    Any object referenced in SQL but not a key is treated as TABLE.
    """

    def __init__(self, json_path: str):
        path = Path(json_path)
        if not path.exists():
            raise FileNotFoundError(f"Mock views file not found: {json_path}")
        with path.open("r", encoding="utf-8") as f:
            self.views: Dict[str, str] = json.load(f)

    def get_view_definition(self, view_name: str) -> Optional[str]:
        return self.views.get(view_name)

    def get_object_type(self, object_name: str) -> str:
        if object_name in self.views:
            return "VIEW"
        return "TABLE"


class RealTeradataViewProvider:
    """Template for a real Teradata-backed provider.

    NOTE:
    - We import teradatasql lazily so mock mode still works when the
      driver is not installed.
    - You must adjust connection details to your environment.
    """

    def __init__(self, host: str, user: str, password: str, database: Optional[str] = None):
        import teradatasql  # type: ignore

        self._td = teradatasql
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self._conn = self._td.connect(
            host=self.host,
            user=self.user,
            password=self.password,
        )

    def _cursor(self):
        return self._conn.cursor()

    def get_view_definition(self, view_name: str) -> Optional[str]:
        sql = f"SHOW VIEW {view_name};"
        cur = self._cursor()
        cur.execute(sql)
        parts = []
        for row in cur.fetchall():
            parts.append(str(row[0]))
        if not parts:
            return None
        return "\n".join(parts)

    def get_object_type(self, object_name: str) -> str:
        # Supports db.table or just table (uses default database)
        if "." in object_name:
            db_name, tbl_name = object_name.split(".", 1)
        else:
            db_name = self.database
            tbl_name = object_name

        if not db_name:
            where_clause = "TableName = ?"
            params = [tbl_name]
        else:
            where_clause = "DatabaseName = ? AND TableName = ?"
            params = [db_name, tbl_name]

        query = f"""
            SELECT TableKind
            FROM DBC.TablesV
            WHERE {where_clause}
            QUALIFY ROW_NUMBER() OVER (ORDER BY DatabaseName, TableName) = 1;
        """

        cur = self._cursor()
        cur.execute(query, params)
        row = cur.fetchone()
        if not row:
            return "UNKNOWN"

        kind = row[0]
        if kind == "V":
            return "VIEW"
        if kind in ("T", "O"):
            return "TABLE"
        return "UNKNOWN"