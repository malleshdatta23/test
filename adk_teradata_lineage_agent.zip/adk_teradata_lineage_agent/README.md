# Teradata Lineage ADK Agent (Mock + Real Modes)

This project wraps the Python lineage engine inside an **ADK agent** so that
Gemini can call a tool to build Teradata lineage.

You get **both modes**:

- `mock`  → uses a local JSON file with view definitions (no DB needed)
- `teradata` → uses a real Teradata connection with `SHOW VIEW` + `DBC.TablesV`

---

## 1. Folder Structure

- `agent.yaml`                 → ADK agent definition
- `tools/lineage_tool.py`      → ADK tool that calls the lineage engine
- `tools/requirements.txt`     → Python deps for the tool
- `lineage_engine/`            → Pure Python lineage engine (no ADK)
    - `parser.py`
    - `lineage_builder.py`
    - `teradata_client.py`
    - `__init__.py`
- `examples/mock_views.json`   → Sample mock view definitions

---

## 2. Using in AntiGravity / ADK

From the project root (this folder):

```bash
# (Exact command may vary slightly depending on your ADK version)
adk agent run agent.yaml
```

Then ask the agent something like:

> "Get lineage for COE_UAT_ALLVM.TSPOT_VZW_REF_HANDSET_EQUIPMENT_V in mock mode"

The agent will:
1. Decide to call the tool `get_teradata_lineage`.
2. The tool will call the Python lineage engine.
3. The engine will:
   - For `mode="mock"` → use `examples/mock_views.json`
   - For `mode="teradata"` → call Teradata via `RealTeradataViewProvider`.
4. Return lineage as JSON. The agent then explains it in natural language.

---

## 3. Tool Usage (direct, outside ADK)

You can also run the tool logic directly in Python:

```python
from tools.lineage_tool import get_teradata_lineage

result = get_teradata_lineage(
    view_name="v1",
    mode="mock",
    database=None,
    mock_file_path="examples/mock_views.json"
)

print(result)
```

The return value is a nested JSON-like `dict` with:

```json
{
  "name": "<root view>",
  "type": "VIEW",
  "children": [
     { "name": "...", "type": "VIEW/TABLE", "children": [...] }
  ]
}
```

---

## 4. Switching to Real Teradata

1. Install `teradatasql` inside the environment where the tool runs.
2. Edit `tools/lineage_tool.py`:
   - Fill in the correct `host`, `user`, and `password` handling
     (ideally from environment variables or secret manager).
3. Call the tool with `mode="teradata"`.

Example (conceptual):

```python
get_teradata_lineage(
    view_name="COE_UAT_ALLVM.TSPOT_VZW_REF_HANDSET_EQUIPMENT_V",
    mode="teradata",
    database="COE_UAT_ALLVM"
)
```

The lineage engine will:
- Run `SHOW VIEW <view_name>` recursively.
- Use `DBC.TablesV` to distinguish VIEW vs TABLE.
- Build the full lineage tree.